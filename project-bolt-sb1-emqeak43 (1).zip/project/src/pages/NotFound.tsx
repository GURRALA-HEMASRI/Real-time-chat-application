import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { HomeIcon } from 'lucide-react';

const NotFound = () => {
  const { isAuthenticated } = useAuth();
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 p-4">
      <div className="text-center">
        <h1 className="text-9xl font-bold text-primary-500">404</h1>
        <h2 className="text-3xl font-bold mt-4 mb-6 text-gray-800 dark:text-gray-200">Page not found</h2>
        <p className="text-lg text-gray-600 dark:text-gray-400 mb-8">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <Link
          to={isAuthenticated ? '/chat' : '/login'}
          className="inline-flex items-center px-6 py-3 rounded-lg bg-primary-500 text-white font-medium hover:bg-primary-600 transition-colors"
        >
          <HomeIcon className="mr-2" size={20} />
          {isAuthenticated ? 'Go to Chat' : 'Go to Login'}
        </Link>
      </div>
    </div>
  );
};

export default NotFound;