import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { 
  Bell, 
  Moon, 
  Sun, 
  Lock, 
  Trash2, 
  LogOut, 
  User, 
  Save,
  Camera
} from 'lucide-react';
import { motion } from 'framer-motion';

const Settings = () => {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  
  const [username, setUsername] = useState(user?.username || '');
  const [email, setEmail] = useState(user?.email || '');
  const [bio, setBio] = useState('Frontend Developer | Coffee enthusiast | Dog lover');
  
  // Notification settings
  const [notificationSettings, setNotificationSettings] = useState({
    enableSound: true,
    messagePreview: true,
    showOnline: true,
    emailNotifications: false,
  });
  
  const handleNotificationChange = (setting: keyof typeof notificationSettings) => {
    setNotificationSettings(prev => ({
      ...prev,
      [setting]: !prev[setting],
    }));
  };
  
  // Save profile changes
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you would make an API call to update the user profile
    alert('Profile updated successfully!');
  };
  
  return (
    <div className="h-full overflow-y-auto p-6 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Settings</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Sidebar */}
          <div className="md:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
              <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                <div className="flex flex-col items-center">
                  <div className="relative group">
                    <div className="w-24 h-24 rounded-full overflow-hidden mb-3">
                      <img 
                        src={user?.avatar || "https://i.pravatar.cc/150?img=68"} 
                        alt={user?.username} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="bg-black/50 rounded-full w-full h-full flex items-center justify-center">
                        <button className="text-white p-2">
                          <Camera size={24} />
                        </button>
                      </div>
                    </div>
                  </div>
                  <h2 className="text-xl font-semibold">{user?.username}</h2>
                  <p className="text-gray-500 dark:text-gray-400 text-sm">{user?.email}</p>
                </div>
              </div>
              
              <div className="p-1">
                <button className="w-full flex items-center p-3 text-left rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
                  <User className="mr-3 text-gray-500 dark:text-gray-400" size={20} />
                  <span>Profile</span>
                </button>
                
                <button className="w-full flex items-center p-3 text-left rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
                  <Bell className="mr-3 text-gray-500 dark:text-gray-400" size={20} />
                  <span>Notifications</span>
                </button>
                
                <button className="w-full flex items-center p-3 text-left rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
                  <Lock className="mr-3 text-gray-500 dark:text-gray-400" size={20} />
                  <span>Privacy & Security</span>
                </button>
                
                <button 
                  onClick={toggleTheme}
                  className="w-full flex items-center p-3 text-left rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  {theme === 'light' ? (
                    <Moon className="mr-3 text-gray-500 dark:text-gray-400\" size={20} />
                  ) : (
                    <Sun className="mr-3 text-gray-500 dark:text-gray-400" size={20} />
                  )}
                  <span>{theme === 'light' ? 'Dark Mode' : 'Light Mode'}</span>
                </button>
                
                <button 
                  onClick={logout}
                  className="w-full flex items-center p-3 text-left rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <LogOut className="mr-3 text-gray-500 dark:text-gray-400" size={20} />
                  <span>Logout</span>
                </button>
                
                <button className="w-full flex items-center p-3 text-left rounded-lg text-error-600 dark:text-error-400 hover:bg-gray-100 dark:hover:bg-gray-700">
                  <Trash2 className="mr-3" size={20} />
                  <span>Delete Account</span>
                </button>
              </div>
            </div>
          </div>
          
          {/* Main content */}
          <div className="md:col-span-2 space-y-6">
            {/* Profile section */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden"
            >
              <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                <h2 className="text-xl font-semibold">Profile Information</h2>
                <p className="text-gray-500 dark:text-gray-400 text-sm">Update your personal information</p>
              </div>
              
              <form onSubmit={handleSaveProfile} className="p-6">
                <div className="grid grid-cols-1 gap-6">
                  <div>
                    <label htmlFor="username" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Username
                    </label>
                    <input
                      id="username"
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="input"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Email address
                    </label>
                    <input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="input"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="bio" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Bio
                    </label>
                    <textarea
                      id="bio"
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      rows={3}
                      className="input resize-none"
                    />
                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                      Brief description for your profile. URLs are hyperlinked.
                    </p>
                  </div>
                  
                  <div className="flex justify-end">
                    <button type="submit" className="btn-primary flex items-center">
                      <Save className="mr-2" size={18} />
                      Save Changes
                    </button>
                  </div>
                </div>
              </form>
            </motion.div>
            
            {/* Notification section */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden"
            >
              <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                <h2 className="text-xl font-semibold">Notification Settings</h2>
                <p className="text-gray-500 dark:text-gray-400 text-sm">Manage your notification preferences</p>
              </div>
              
              <div className="p-6">
                <div className="divide-y divide-gray-200 dark:divide-gray-700">
                  <div className="py-4 flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">Enable sound notifications</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Play a sound when you receive a new message</p>
                    </div>
                    <div className="ml-4">
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          checked={notificationSettings.enableSound}
                          onChange={() => handleNotificationChange('enableSound')}
                          className="sr-only peer" 
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-500"></div>
                      </label>
                    </div>
                  </div>
                  
                  <div className="py-4 flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">Show message previews</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Show message content in notifications</p>
                    </div>
                    <div className="ml-4">
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          checked={notificationSettings.messagePreview}
                          onChange={() => handleNotificationChange('messagePreview')}
                          className="sr-only peer" 
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-500"></div>
                      </label>
                    </div>
                  </div>
                  
                  <div className="py-4 flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">Show when I'm online</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Let other users see when you're active</p>
                    </div>
                    <div className="ml-4">
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          checked={notificationSettings.showOnline}
                          onChange={() => handleNotificationChange('showOnline')}
                          className="sr-only peer" 
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-500"></div>
                      </label>
                    </div>
                  </div>
                  
                  <div className="py-4 flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">Email notifications</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Receive email notifications for unread messages</p>
                    </div>
                    <div className="ml-4">
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          checked={notificationSettings.emailNotifications}
                          onChange={() => handleNotificationChange('emailNotifications')}
                          className="sr-only peer" 
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-500"></div>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;