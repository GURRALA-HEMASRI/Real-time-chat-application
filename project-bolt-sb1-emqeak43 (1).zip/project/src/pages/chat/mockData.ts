import { Chat, Message } from './Chat';

// Generate mock chats
export const generateMockChats = (): Chat[] => {
  return [
    {
      id: '1',
      isGroup: false,
      participants: [
        {
          id: '2',
          username: 'Sarah Johnson',
          avatar: 'https://i.pravatar.cc/150?img=32',
          status: 'online'
        }
      ],
      lastMessage: {
        content: 'Sure, let\'s meet tomorrow at 10am',
        timestamp: new Date(Date.now() - 35 * 60 * 1000),
        senderId: '2'
      },
      unreadCount: 0
    },
    {
      id: '2',
      isGroup: false,
      participants: [
        {
          id: '3',
          username: 'Michael Chen',
          avatar: 'https://i.pravatar.cc/150?img=4',
          status: 'offline'
        }
      ],
      lastMessage: {
        content: 'Did you get a chance to review the document?',
        timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
        senderId: '3'
      },
      unreadCount: 2
    },
    {
      id: '3',
      isGroup: true,
      name: 'Project Alpha Team',
      avatar: 'https://i.pravatar.cc/150?img=53',
      participants: [
        {
          id: '4',
          username: 'Alex Rodriguez',
          avatar: 'https://i.pravatar.cc/150?img=3',
          status: 'online'
        },
        {
          id: '5',
          username: 'Olivia Kim',
          avatar: 'https://i.pravatar.cc/150?img=5',
          status: 'away'
        },
        {
          id: '6',
          username: 'Ethan Moore',
          avatar: 'https://i.pravatar.cc/150?img=12',
          status: 'online'
        }
      ],
      lastMessage: {
        content: 'The deadline has been extended to next Friday',
        timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000),
        senderId: '5'
      },
      unreadCount: 5
    },
    {
      id: '4',
      isGroup: false,
      participants: [
        {
          id: '7',
          username: 'Emma Wilson',
          avatar: 'https://i.pravatar.cc/150?img=9',
          status: 'online'
        }
      ],
      lastMessage: {
        content: 'Happy birthday! 🎉',
        timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
        senderId: '1'
      },
      unreadCount: 0
    },
    {
      id: '5',
      isGroup: false,
      participants: [
        {
          id: '8',
          username: 'James Lee',
          avatar: 'https://i.pravatar.cc/150?img=13',
          status: 'offline'
        }
      ],
      lastMessage: {
        content: 'Can you send me the address for Saturday\'s event?',
        timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        senderId: '8'
      },
      unreadCount: 0
    },
    {
      id: '6',
      isGroup: true,
      name: 'Family Group',
      avatar: 'https://i.pravatar.cc/150?img=30',
      participants: [
        {
          id: '9',
          username: 'Mom',
          avatar: 'https://i.pravatar.cc/150?img=43',
          status: 'online'
        },
        {
          id: '10',
          username: 'Dad',
          avatar: 'https://i.pravatar.cc/150?img=70',
          status: 'offline'
        },
        {
          id: '11',
          username: 'Sister',
          avatar: 'https://i.pravatar.cc/150?img=42',
          status: 'away'
        }
      ],
      lastMessage: {
        content: 'Don\'t forget we\'re having dinner at 7pm tonight',
        timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        senderId: '9'
      },
      unreadCount: 0
    }
  ];
};

// Generate mock messages for a chat
export const generateMockMessages = (currentUserId: string, chatId: string): Message[] => {
  // Different message sets based on chat ID
  switch(chatId) {
    case '1': // Sarah Johnson
      return [
        {
          id: '101',
          content: 'Hi there! How are you today?',
          sender: {
            id: '2',
            username: 'Sarah Johnson',
            avatar: 'https://i.pravatar.cc/150?img=32'
          },
          timestamp: new Date(Date.now() - 120 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '102',
          content: 'I\'m doing well, thanks for asking! How about you?',
          sender: {
            id: currentUserId,
            username: 'You',
            avatar: 'https://i.pravatar.cc/150?img=68'
          },
          timestamp: new Date(Date.now() - 118 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '103',
          content: 'Pretty good! I was wondering if you\'re free to meet up tomorrow?',
          sender: {
            id: '2',
            username: 'Sarah Johnson',
            avatar: 'https://i.pravatar.cc/150?img=32'
          },
          timestamp: new Date(Date.now() - 115 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '104',
          content: 'Yes, I should be free. What time were you thinking?',
          sender: {
            id: currentUserId,
            username: 'You',
            avatar: 'https://i.pravatar.cc/150?img=68'
          },
          timestamp: new Date(Date.now() - 110 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '105',
          content: 'How about around 10am? We could grab coffee at that new place downtown.',
          sender: {
            id: '2',
            username: 'Sarah Johnson',
            avatar: 'https://i.pravatar.cc/150?img=32'
          },
          timestamp: new Date(Date.now() - 105 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '106',
          content: 'Sounds perfect! I\'ve been wanting to check that place out.',
          sender: {
            id: currentUserId,
            username: 'You',
            avatar: 'https://i.pravatar.cc/150?img=68'
          },
          timestamp: new Date(Date.now() - 100 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '107',
          content: 'Great! Looking forward to it.',
          sender: {
            id: '2',
            username: 'Sarah Johnson',
            avatar: 'https://i.pravatar.cc/150?img=32'
          },
          timestamp: new Date(Date.now() - 95 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '108',
          content: 'By the way, did you finish that report for work?',
          sender: {
            id: '2',
            username: 'Sarah Johnson',
            avatar: 'https://i.pravatar.cc/150?img=32'
          },
          timestamp: new Date(Date.now() - 40 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '109',
          content: 'Yes, just submitted it this morning. It was quite a challenge!',
          sender: {
            id: currentUserId,
            username: 'You',
            avatar: 'https://i.pravatar.cc/150?img=68'
          },
          timestamp: new Date(Date.now() - 38 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '110',
          content: 'Sure, let\'s meet tomorrow at 10am',
          sender: {
            id: '2',
            username: 'Sarah Johnson',
            avatar: 'https://i.pravatar.cc/150?img=32'
          },
          timestamp: new Date(Date.now() - 35 * 60 * 1000),
          status: 'read',
          type: 'text'
        }
      ];
      
    case '2': // Michael Chen
      return [
        {
          id: '201',
          content: 'Hey, I sent over the document for the upcoming presentation. Could you take a look when you get a chance?',
          sender: {
            id: '3',
            username: 'Michael Chen',
            avatar: 'https://i.pravatar.cc/150?img=4'
          },
          timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '202',
          content: 'Sure thing. I\'ll review it this afternoon.',
          sender: {
            id: currentUserId,
            username: 'You',
            avatar: 'https://i.pravatar.cc/150?img=68'
          },
          timestamp: new Date(Date.now() - 4.5 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '203',
          content: 'Great, thanks! I\'m especially interested in your thoughts on the market analysis section.',
          sender: {
            id: '3',
            username: 'Michael Chen',
            avatar: 'https://i.pravatar.cc/150?img=4'
          },
          timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '204',
          content: 'No problem. I have some experience in that area, so I should be able to provide good feedback.',
          sender: {
            id: currentUserId,
            username: 'You',
            avatar: 'https://i.pravatar.cc/150?img=68'
          },
          timestamp: new Date(Date.now() - 3.8 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '205',
          content: 'Perfect! Also, are we still on for the team lunch next week?',
          sender: {
            id: '3',
            username: 'Michael Chen',
            avatar: 'https://i.pravatar.cc/150?img=4'
          },
          timestamp: new Date(Date.now() - 3.5 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '206',
          content: 'Yes, I\'ve got it on my calendar. Looking forward to it!',
          sender: {
            id: currentUserId,
            username: 'You',
            avatar: 'https://i.pravatar.cc/150?img=68'
          },
          timestamp: new Date(Date.now() - 3.2 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '207',
          content: 'Did you get a chance to review the document?',
          sender: {
            id: '3',
            username: 'Michael Chen',
            avatar: 'https://i.pravatar.cc/150?img=4'
          },
          timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
          status: 'delivered',
          type: 'text'
        }
      ];
      
    case '3': // Project Alpha Team
      return [
        {
          id: '301',
          content: 'Hi team! Just a reminder that our project status meeting is tomorrow at 2pm.',
          sender: {
            id: '4',
            username: 'Alex Rodriguez',
            avatar: 'https://i.pravatar.cc/150?img=3'
          },
          timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '302',
          content: 'Thanks for the reminder, Alex. I\'ll prepare my section of the presentation.',
          sender: {
            id: currentUserId,
            username: 'You',
            avatar: 'https://i.pravatar.cc/150?img=68'
          },
          timestamp: new Date(Date.now() - 23 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '303',
          content: 'I\'ve uploaded the latest designs to the shared folder. Please take a look when you can.',
          sender: {
            id: '5',
            username: 'Olivia Kim',
            avatar: 'https://i.pravatar.cc/150?img=5'
          },
          timestamp: new Date(Date.now() - 20 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '304',
          content: 'The designs look great, Olivia! I especially like the new color scheme.',
          sender: {
            id: '6',
            username: 'Ethan Moore',
            avatar: 'https://i.pravatar.cc/150?img=12'
          },
          timestamp: new Date(Date.now() - 18 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '305',
          content: 'I agree with Ethan. The new designs are a big improvement.',
          sender: {
            id: currentUserId,
            username: 'You',
            avatar: 'https://i.pravatar.cc/150?img=68'
          },
          timestamp: new Date(Date.now() - 16 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '306',
          content: 'Thanks everyone! I worked hard on those revisions.',
          sender: {
            id: '5',
            username: 'Olivia Kim',
            avatar: 'https://i.pravatar.cc/150?img=5'
          },
          timestamp: new Date(Date.now() - 15 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '307',
          content: 'Has anyone heard back from the client about the timeline?',
          sender: {
            id: '4',
            username: 'Alex Rodriguez',
            avatar: 'https://i.pravatar.cc/150?img=3'
          },
          timestamp: new Date(Date.now() - 14 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '308',
          content: 'I spoke with them this morning. They\'ve requested an additional week for the first phase.',
          sender: {
            id: '6',
            username: 'Ethan Moore',
            avatar: 'https://i.pravatar.cc/150?img=12'
          },
          timestamp: new Date(Date.now() - 13 * 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '309',
          content: 'The deadline has been extended to next Friday',
          sender: {
            id: '5',
            username: 'Olivia Kim',
            avatar: 'https://i.pravatar.cc/150?img=5'
          },
          timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000),
          status: 'delivered',
          type: 'text'
        }
      ];
      
    default:
      // Generic conversation
      return [
        {
          id: '901',
          content: 'Hello there!',
          sender: {
            id: chatId,
            username: 'User',
            avatar: 'https://i.pravatar.cc/150?img=33'
          },
          timestamp: new Date(Date.now() - 60 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '902',
          content: 'Hi! How can I help you today?',
          sender: {
            id: currentUserId,
            username: 'You',
            avatar: 'https://i.pravatar.cc/150?img=68'
          },
          timestamp: new Date(Date.now() - 59 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '903',
          content: 'Just wanted to check in and see how things are going with the project.',
          sender: {
            id: chatId,
            username: 'User',
            avatar: 'https://i.pravatar.cc/150?img=33'
          },
          timestamp: new Date(Date.now() - 58 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '904',
          content: 'Everything is on track. We should be able to deliver on time.',
          sender: {
            id: currentUserId,
            username: 'You',
            avatar: 'https://i.pravatar.cc/150?img=68'
          },
          timestamp: new Date(Date.now() - 57 * 60 * 1000),
          status: 'read',
          type: 'text'
        },
        {
          id: '905',
          content: 'That\'s great to hear! Let me know if you need anything from my end.',
          sender: {
            id: chatId,
            username: 'User',
            avatar: 'https://i.pravatar.cc/150?img=33'
          },
          timestamp: new Date(Date.now() - 56 * 60 * 1000),
          status: 'read',
          type: 'text'
        }
      ];
  }
};