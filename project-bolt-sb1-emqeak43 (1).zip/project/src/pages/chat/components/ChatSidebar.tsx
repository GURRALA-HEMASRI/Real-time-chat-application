import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Search, Plus, ChevronDown } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Chat } from '../Chat';
import { motion } from 'framer-motion';

type ChatSidebarProps = {
  chats: Chat[];
  activeChat: Chat | null;
};

const ChatSidebar = ({ chats, activeChat }: ChatSidebarProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  
  // Filter chats based on search query
  const filteredChats = chats.filter(chat => {
    const name = chat.name || chat.participants[0]?.username || '';
    return name.toLowerCase().includes(searchQuery.toLowerCase());
  });
  
  return (
    <div className="w-full md:w-80 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="relative">
          <input
            type="text"
            placeholder="Search conversations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          />
          <Search className="absolute left-3 top-2.5 text-gray-400 dark:text-gray-500" size={20} />
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        <div className="p-4 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Messages</h2>
          <button className="p-1.5 rounded-full bg-primary-500 text-white hover:bg-primary-600 transition-colors">
            <Plus size={18} />
          </button>
        </div>
        
        {filteredChats.length === 0 ? (
          <div className="p-4 text-center text-gray-500 dark:text-gray-400">
            No conversations found
          </div>
        ) : (
          <div className="space-y-1 px-3">
            {filteredChats.map((chat) => {
              const isActive = activeChat?.id === chat.id;
              const chatName = chat.name || chat.participants[0]?.username || 'Unknown';
              const lastMessage = chat.lastMessage?.content || 'No messages yet';
              const avatar = chat.isGroup
                ? chat.avatar
                : chat.participants[0]?.avatar;
              const lastMessageTime = chat.lastMessage?.timestamp
                ? formatDistanceToNow(new Date(chat.lastMessage.timestamp), { addSuffix: true })
                : '';
              
              return (
                <motion.div
                  key={chat.id}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <NavLink
                    to={`/chat/${chat.id}`}
                    className={`flex items-center p-3 rounded-lg ${
                      isActive
                        ? 'bg-primary-50 dark:bg-primary-900/30'
                        : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    <div className="relative">
                      <div className="w-12 h-12 rounded-full overflow-hidden">
                        <img
                          src={avatar || 'https://i.pravatar.cc/150?img=60'}
                          alt={chatName}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      {chat.participants.some(p => p.status === 'online') && (
                        <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-accent-500 border-2 border-white dark:border-gray-800 rounded-full"></div>
                      )}
                    </div>
                    
                    <div className="ml-3 flex-1 overflow-hidden">
                      <div className="flex justify-between items-center">
                        <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
                          {chatName}
                        </h3>
                        <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">
                          {lastMessageTime}
                        </span>
                      </div>
                      
                      <div className="flex justify-between items-center mt-1">
                        <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                          {lastMessage}
                        </p>
                        
                        {chat.unreadCount > 0 && (
                          <span className="ml-2 flex items-center justify-center w-5 h-5 bg-primary-500 text-white text-xs font-medium rounded-full">
                            {chat.unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                  </NavLink>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatSidebar;