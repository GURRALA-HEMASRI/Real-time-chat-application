import { useState, useRef, useEffect } from 'react';
import { 
  Smile, 
  Paperclip, 
  Camera, 
  Mic, 
  Send
} from 'lucide-react';

type MessageInputProps = {
  onSendMessage: (message: string) => void;
  onTypingStart: () => void;
  onTypingStop: () => void;
};

const MessageInput = ({ onSendMessage, onTypingStart, onTypingStop }: MessageInputProps) => {
  const [message, setMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  // Auto-resize textarea
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.style.height = `${Math.min(inputRef.current.scrollHeight, 120)}px`;
    }
  }, [message]);
  
  // Handle typing indicator
  useEffect(() => {
    if (message && !isTyping) {
      setIsTyping(true);
      onTypingStart();
    }
    
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    
    if (message) {
      typingTimeoutRef.current = setTimeout(() => {
        setIsTyping(false);
        onTypingStop();
      }, 2000);
    } else if (isTyping) {
      setIsTyping(false);
      onTypingStop();
    }
    
    return () => {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    };
  }, [message, isTyping, onTypingStart, onTypingStop]);
  
  const handleSendMessage = () => {
    if (message.trim()) {
      onSendMessage(message.trim());
      setMessage('');
      if (inputRef.current) {
        inputRef.current.style.height = 'auto';
      }
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  return (
    <div className="p-3 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
      <div className="flex items-end gap-2">
        <div className="flex-shrink-0 flex space-x-1">
          <button className="p-2 rounded-full text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700">
            <Smile size={20} />
          </button>
        </div>
        
        <div className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-2xl p-1 flex items-end">
          <textarea
            ref={inputRef}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type a message..."
            className="flex-1 max-h-32 bg-transparent border-0 focus:ring-0 resize-none py-2 px-3 text-gray-800 dark:text-gray-200 placeholder-gray-500 dark:placeholder-gray-400"
            rows={1}
          />
          
          <div className="flex-shrink-0 flex items-center space-x-1 pb-1 pr-1">
            <button className="p-2 rounded-full text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-600">
              <Paperclip size={18} />
            </button>
            <button className="p-2 rounded-full text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-600">
              <Camera size={18} />
            </button>
            <button className="p-2 rounded-full text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-600">
              <Mic size={18} />
            </button>
          </div>
        </div>
        
        <button
          onClick={handleSendMessage}
          disabled={!message.trim()}
          className={`p-3 rounded-full ${
            message.trim()
              ? 'bg-primary-500 text-white hover:bg-primary-600'
              : 'bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400'
          } transition-colors`}
        >
          <Send size={18} />
        </button>
      </div>
    </div>
  );
};

export default MessageInput;