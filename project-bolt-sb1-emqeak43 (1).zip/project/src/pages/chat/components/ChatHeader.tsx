import { useState } from 'react';
import { Phone, Video, Info, MoreVertical, ArrowLeft } from 'lucide-react';
import { Chat } from '../Chat';
import { motion, AnimatePresence } from 'framer-motion';

type ChatHeaderProps = {
  chat: Chat;
};

const ChatHeader = ({ chat }: ChatHeaderProps) => {
  const [showMenu, setShowMenu] = useState(false);
  
  const chatName = chat.name || chat.participants[0]?.username || 'Unknown';
  const avatar = chat.isGroup
    ? chat.avatar
    : chat.participants[0]?.avatar;
  
  // Get online status text
  const getStatusText = () => {
    if (chat.isGroup) {
      const onlineCount = chat.participants.filter(p => p.status === 'online').length;
      return `${onlineCount} online`;
    } else {
      const status = chat.participants[0]?.status;
      return status === 'online' ? 'Online' : status === 'away' ? 'Away' : 'Offline';
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-3 flex items-center">
      <button className="md:hidden p-2 mr-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
        <ArrowLeft size={20} />
      </button>
      
      <div className="flex items-center flex-1">
        <div className="relative">
          <div className="w-10 h-10 rounded-full overflow-hidden">
            <img
              src={avatar || 'https://i.pravatar.cc/150?img=33'}
              alt={chatName}
              className="w-full h-full object-cover"
            />
          </div>
          
          {!chat.isGroup && chat.participants[0]?.status === 'online' && (
            <div className="absolute bottom-0 right-0 w-3 h-3 bg-accent-500 border-2 border-white dark:border-gray-800 rounded-full"></div>
          )}
        </div>
        
        <div className="ml-3">
          <h2 className="text-base font-medium text-gray-900 dark:text-gray-100">{chatName}</h2>
          <p className="text-xs text-gray-500 dark:text-gray-400">{getStatusText()}</p>
        </div>
      </div>
      
      <div className="flex items-center space-x-2">
        <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300">
          <Phone size={20} />
        </button>
        <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300">
          <Video size={20} />
        </button>
        <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300">
          <Info size={20} />
        </button>
        
        <div className="relative">
          <button 
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300"
            onClick={() => setShowMenu(!showMenu)}
          >
            <MoreVertical size={20} />
          </button>
          
          <AnimatePresence>
            {showMenu && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.1 }}
                className="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white dark:bg-gray-800 ring-1 ring-black ring-opacity-5 focus:outline-none z-10"
              >
                <div className="py-1" role="menu" aria-orientation="vertical">
                  <button
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                    role="menuitem"
                  >
                    View profile
                  </button>
                  <button
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                    role="menuitem"
                  >
                    Mute notifications
                  </button>
                  <button
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                    role="menuitem"
                  >
                    Search in conversation
                  </button>
                  <button
                    className="w-full text-left px-4 py-2 text-sm text-error-600 dark:text-error-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                    role="menuitem"
                  >
                    Block {chat.isGroup ? 'group' : 'user'}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default ChatHeader;