import { useRef, useEffect } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Message } from '../Chat';
import { Check, CheckCheck } from 'lucide-react';
import { motion } from 'framer-motion';

type MessageListProps = {
  messages: Message[];
  currentUserId: string;
};

const MessageList = ({ messages, currentUserId }: MessageListProps) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Auto-scroll to bottom when new messages are added
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  const renderStatusIcon = (status: string) => {
    switch (status) {
      case 'sent':
        return <Check className="w-4 h-4 text-gray-400" />;
      case 'delivered':
        return <Check className="w-4 h-4 text-gray-400" />;
      case 'read':
        return <CheckCheck className="w-4 h-4 text-primary-500" />;
      default:
        return null;
    }
  };
  
  // Group messages by date
  const groupedMessages: { [date: string]: Message[] } = {};
  
  messages.forEach(message => {
    const date = new Date(message.timestamp).toDateString();
    if (!groupedMessages[date]) {
      groupedMessages[date] = [];
    }
    groupedMessages[date].push(message);
  });
  
  return (
    <div className="space-y-6">
      {Object.entries(groupedMessages).map(([date, dateMessages]) => (
        <div key={date}>
          <div className="flex justify-center mb-4">
            <div className="px-3 py-1 bg-gray-200 dark:bg-gray-700 rounded-full text-xs text-gray-600 dark:text-gray-300">
              {new Date(date).toLocaleDateString(undefined, { 
                weekday: 'long', 
                month: 'short', 
                day: 'numeric' 
              })}
            </div>
          </div>
          
          <div className="space-y-3">
            {dateMessages.map((message, index) => {
              const isCurrentUser = message.sender.id === currentUserId;
              const showAvatar = 
                index === 0 || 
                dateMessages[index - 1].sender.id !== message.sender.id;
              
              return (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                  className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'} max-w-[80%]`}>
                    {!isCurrentUser && showAvatar && (
                      <div className="flex-shrink-0 w-8 h-8 rounded-full overflow-hidden mr-2">
                        <img 
                          src={message.sender.avatar || "https://i.pravatar.cc/150?img=33"} 
                          alt={message.sender.username} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                    
                    {!isCurrentUser && !showAvatar && <div className="w-8 mr-2"></div>}
                    
                    <div className={`flex flex-col ${isCurrentUser ? 'items-end' : 'items-start'}`}>
                      {showAvatar && !isCurrentUser && (
                        <span className="text-xs text-gray-500 dark:text-gray-400 ml-2 mb-1">
                          {message.sender.username}
                        </span>
                      )}
                      
                      <div
                        className={`rounded-2xl py-2 px-4 ${
                          isCurrentUser
                            ? 'bg-primary-500 text-white rounded-tr-none'
                            : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white rounded-tl-none'
                        }`}
                      >
                        <p className="whitespace-pre-wrap break-words">{message.content}</p>
                      </div>
                      
                      <div className={`flex items-center mt-1 ${isCurrentUser ? 'justify-end' : 'justify-start'}`}>
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          {formatDistanceToNow(new Date(message.timestamp), { addSuffix: true })}
                        </span>
                        
                        {isCurrentUser && (
                          <span className="ml-1">{renderStatusIcon(message.status)}</span>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      ))}
      <div ref={messagesEndRef} />
    </div>
  );
};

export default MessageList;