import { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { io, Socket } from 'socket.io-client';
import { SOCKET_URL } from '../../config/constants';
import ChatSidebar from './components/ChatSidebar';
import ChatHeader from './components/ChatHeader';
import MessageList from './components/MessageList';
import MessageInput from './components/MessageInput';
import { useAuth } from '../../context/AuthContext';
import { formatDistanceToNow } from 'date-fns';
import { generateMockChats, generateMockMessages } from './mockData';

// Message type definition
export type Message = {
  id: string;
  content: string;
  sender: {
    id: string;
    username: string;
    avatar?: string;
  };
  timestamp: Date;
  status: 'sent' | 'delivered' | 'read';
  type: 'text' | 'image' | 'file';
};

// Chat type definition
export type Chat = {
  id: string;
  name?: string;
  avatar?: string;
  isGroup: boolean;
  participants: {
    id: string;
    username: string;
    avatar?: string;
    status?: 'online' | 'offline' | 'away';
  }[];
  lastMessage?: {
    content: string;
    timestamp: Date;
    senderId: string;
  };
  unreadCount: number;
};

const Chat = () => {
  const { id: chatId } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [socket, setSocket] = useState<Socket | null>(null);
  const [chats, setChats] = useState<Chat[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [activeChat, setActiveChat] = useState<Chat | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Initialize socket connection
  useEffect(() => {
    // In a real app, you would connect to your Socket.io server
    // For demo purposes, we'll just mock the data
    // const newSocket = io(SOCKET_URL);
    // setSocket(newSocket);
    
    // Initialize mock data
    const mockChats = generateMockChats();
    setChats(mockChats);
    
    // Select first chat if none is selected
    if (chatId) {
      const selectedChat = mockChats.find(chat => chat.id === chatId);
      if (selectedChat) {
        setActiveChat(selectedChat);
        setMessages(generateMockMessages(user?.id || '', selectedChat.id));
      }
    } else if (mockChats.length > 0) {
      setActiveChat(mockChats[0]);
      setMessages(generateMockMessages(user?.id || '', mockChats[0].id));
    }
    
    // Clean up function
    return () => {
      // if (socket) socket.disconnect();
    };
  }, [chatId, user?.id]);
  
  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  // Handle changing active chat
  useEffect(() => {
    if (chatId && chats.length > 0) {
      const chat = chats.find(c => c.id === chatId);
      if (chat) {
        setActiveChat(chat);
        setMessages(generateMockMessages(user?.id || '', chat.id));
      }
    }
  }, [chatId, chats, user?.id]);
  
  // Send a message
  const sendMessage = (content: string) => {
    if (!activeChat || !user || !content.trim()) return;
    
    const newMessage: Message = {
      id: Date.now().toString(),
      content,
      sender: {
        id: user.id,
        username: user.username,
        avatar: user.avatar,
      },
      timestamp: new Date(),
      status: 'sent',
      type: 'text',
    };
    
    setMessages(prev => [...prev, newMessage]);
    
    // Update last message in chat list
    setChats(prev =>
      prev.map(chat => {
        if (chat.id === activeChat.id) {
          return {
            ...chat,
            lastMessage: {
              content,
              timestamp: new Date(),
              senderId: user.id,
            },
          };
        }
        return chat;
      })
    );
    
    // In a real app, you would emit the message to your Socket.io server
    // socket?.emit('send_message', {
    //   chatId: activeChat.id,
    //   content,
    //   senderId: user.id,
    // });
    
    // Simulate receiving a response after a delay
    setTimeout(() => {
      const response: Message = {
        id: (Date.now() + 1).toString(),
        content: getRandomResponse(),
        sender: activeChat.participants.find(p => p.id !== user.id) || {
          id: 'bot',
          username: 'ChatBot',
          avatar: 'https://i.pravatar.cc/150?img=40',
        },
        timestamp: new Date(),
        status: 'delivered',
        type: 'text',
      };
      
      setMessages(prev => [...prev, response]);
      
      // Update last message in chat list
      setChats(prev =>
        prev.map(chat => {
          if (chat.id === activeChat.id) {
            return {
              ...chat,
              lastMessage: {
                content: response.content,
                timestamp: new Date(),
                senderId: response.sender.id,
              },
            };
          }
          return chat;
        })
      );
    }, 1000 + Math.random() * 2000);
  };
  
  // Random responses for demo
  const getRandomResponse = () => {
    const responses = [
      'That sounds great!',
      'I understand what you mean.',
      'Could you elaborate on that?',
      'Let me think about it and get back to you.',
      'That\'s interesting. Tell me more!',
      'I completely agree with you.',
      'I\'m not sure I follow. Can you explain?',
      'That\'s a great point you\'re making.',
      'I appreciate your perspective on this.',
      'Let\'s discuss this further next time we meet.',
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };
  
  // Handle typing indicator
  const handleTypingStart = () => {
    if (!activeChat) return;
    
    // In a real app, you would emit to your Socket.io server
    // socket?.emit('typing_start', {
    //   chatId: activeChat.id,
    //   userId: user?.id,
    // });
  };
  
  const handleTypingStop = () => {
    if (!activeChat) return;
    
    // In a real app, you would emit to your Socket.io server
    // socket?.emit('typing_stop', {
    //   chatId: activeChat.id,
    //   userId: user?.id,
    // });
  };
  
  // For demo, randomly show typing indicator
  useEffect(() => {
    if (activeChat && messages.length > 0) {
      const randomTimeout = Math.random() * 10000;
      const typingTimeout = setTimeout(() => {
        setIsTyping(true);
        setTimeout(() => setIsTyping(false), 2000);
      }, randomTimeout);
      
      return () => clearTimeout(typingTimeout);
    }
  }, [activeChat, messages]);
  
  if (!user) return null;
  
  return (
    <div className="h-screen flex flex-col md:flex-row overflow-hidden">
      {/* Chat list sidebar */}
      <ChatSidebar chats={chats} activeChat={activeChat} />
      
      {/* Main chat area */}
      <div className="flex-1 flex flex-col">
        {activeChat ? (
          <>
            <ChatHeader chat={activeChat} />
            
            <div className="flex-1 overflow-y-auto p-4 bg-gray-50 dark:bg-gray-900">
              <MessageList 
                messages={messages} 
                currentUserId={user.id} 
              />
              
              {isTyping && (
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 rounded-full overflow-hidden mr-2">
                    <img 
                      src={activeChat.participants.find(p => p.id !== user.id)?.avatar || "https://i.pravatar.cc/150?img=40"} 
                      alt="User avatar" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="bg-gray-200 dark:bg-gray-700 rounded-full py-2 px-4">
                    <div className="flex items-center space-x-1">
                      <div className="typing-dot animate-typing-dot"></div>
                      <div className="typing-dot animate-typing-dot"></div>
                      <div className="typing-dot animate-typing-dot"></div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
            
            <MessageInput 
              onSendMessage={sendMessage} 
              onTypingStart={handleTypingStart}
              onTypingStop={handleTypingStop}
            />
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-900">
            <div className="text-center p-8">
              <div className="w-20 h-20 bg-gray-200 dark:bg-gray-700 rounded-full mx-auto mb-4 flex items-center justify-center">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-10 w-10 text-gray-400 dark:text-gray-500" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth={2} 
                    d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" 
                  />
                </svg>
              </div>
              <h2 className="text-xl font-semibold mb-2 text-gray-700 dark:text-gray-300">
                Select a chat to start messaging
              </h2>
              <p className="text-gray-500 dark:text-gray-400">
                Choose from your existing conversations or start a new one
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Chat;

export { Chat }