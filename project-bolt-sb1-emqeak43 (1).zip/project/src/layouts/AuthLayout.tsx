import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { MessageSquare } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { Sun, Moon } from 'lucide-react';

const AuthLayout = () => {
  const { isAuthenticated } = useAuth();
  const { theme, toggleTheme } = useTheme();

  // Redirect if already authenticated
  if (isAuthenticated) {
    return <Navigate to="/chat" replace />;
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Left side (branding) */}
      <div className="flex-1 bg-primary-600 dark:bg-primary-900 flex flex-col justify-center items-center p-8 text-white">
        <div className="max-w-md w-full mx-auto">
          <div className="flex items-center justify-center mb-8">
            <MessageSquare size={48} className="mr-4" />
            <h1 className="text-4xl font-bold">ChatSync</h1>
          </div>
          
          <h2 className="text-2xl font-semibold mb-4 text-center">Connect in real-time with anyone, anywhere</h2>
          
          <div className="mb-8 space-y-4 text-center">
            <p className="text-primary-100">Stay connected with friends, family, and colleagues with our intuitive real-time messaging platform.</p>
            <p className="text-primary-100">End-to-end encryption, file sharing, and more - all in one beautiful app.</p>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-white/10 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Secure Messaging</h3>
              <p className="text-sm text-primary-100">Your messages are always encrypted and secure.</p>
            </div>
            <div className="bg-white/10 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Group Chats</h3>
              <p className="text-sm text-primary-100">Create groups for teams, friends, or projects.</p>
            </div>
            <div className="bg-white/10 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">File Sharing</h3>
              <p className="text-sm text-primary-100">Easily share files, photos, and documents.</p>
            </div>
            <div className="bg-white/10 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Cross-Platform</h3>
              <p className="text-sm text-primary-100">Access from any device, anywhere, anytime.</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Right side (auth forms) */}
      <div className="flex-1 flex flex-col justify-center items-center p-8 bg-gray-50 dark:bg-gray-900">
        <button
          onClick={toggleTheme}
          className="absolute top-4 right-4 p-2 rounded-full bg-gray-200 dark:bg-gray-800 text-gray-700 dark:text-gray-300 transition-colors"
          aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
        >
          {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
        </button>
        
        <div className="max-w-md w-full mx-auto">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default AuthLayout;