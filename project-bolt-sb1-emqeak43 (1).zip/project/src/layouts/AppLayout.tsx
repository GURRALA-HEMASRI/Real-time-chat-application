import { useState, useEffect } from 'react';
import { Outlet, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { 
  MessageSquare, 
  Users, 
  Settings, 
  LogOut, 
  Sun, 
  Moon, 
  Menu, 
  X,
  Search
} from 'lucide-react';

const AppLayout = () => {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  
  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);
  
  // Close sidebar on small screens
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setIsSidebarOpen(false);
      } else {
        setIsSidebarOpen(true);
      }
    };
    
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      {/* Mobile header */}
      <header className="md:hidden flex items-center justify-between p-4 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
        
        <div className="flex items-center">
          <MessageSquare className="text-primary-500 mr-2" size={24} />
          <h1 className="text-xl font-bold">ChatSync</h1>
        </div>
        
        <div className="w-10 h-10 rounded-full overflow-hidden">
          <img 
            src={user?.avatar || "https://i.pravatar.cc/150?img=68"} 
            alt={user?.username || "User"} 
            className="w-full h-full object-cover"
          />
        </div>
      </header>
      
      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-gray-900/50 backdrop-blur-sm">
          <div className="h-full w-64 bg-white dark:bg-gray-800 p-4 flex flex-col">
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center">
                <MessageSquare className="text-primary-500 mr-2" size={24} />
                <h1 className="text-xl font-bold">ChatSync</h1>
              </div>
              <button 
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-2 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="flex-1">
              <nav className="space-y-1">
                <NavLink
                  to="/chat"
                  className={({ isActive }) => 
                    `flex items-center px-4 py-3 rounded-lg ${
                      isActive ? 'bg-primary-50 dark:bg-primary-900/50 text-primary-600 dark:text-primary-400' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`
                  }
                >
                  <MessageSquare className="mr-3" size={20} />
                  <span>Messages</span>
                </NavLink>
                
                <NavLink
                  to="/settings"
                  className={({ isActive }) => 
                    `flex items-center px-4 py-3 rounded-lg ${
                      isActive ? 'bg-primary-50 dark:bg-primary-900/50 text-primary-600 dark:text-primary-400' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`
                  }
                >
                  <Settings className="mr-3" size={20} />
                  <span>Settings</span>
                </NavLink>
              </nav>
            </div>
            
            <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
              <div className="flex items-center px-4 py-2">
                <div className="w-10 h-10 rounded-full overflow-hidden mr-3">
                  <img 
                    src={user?.avatar || "https://i.pravatar.cc/150?img=68"} 
                    alt={user?.username || "User"} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{user?.username}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{user?.email}</p>
                </div>
              </div>
              
              <div className="mt-2 space-y-1">
                <button
                  onClick={toggleTheme}
                  className="w-full flex items-center px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
                >
                  {theme === 'light' ? <Moon className="mr-3\" size={20} /> : <Sun className="mr-3" size={20} />}
                  <span>{theme === 'light' ? 'Dark Mode' : 'Light Mode'}</span>
                </button>
                
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
                >
                  <LogOut className="mr-3" size={20} />
                  <span>Logout</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <div className="flex-1 flex">
        {/* Sidebar */}
        <aside className={`hidden md:flex flex-col ${isSidebarOpen ? 'w-72' : 'w-20'} bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transition-all duration-300 ease-in-out`}>
          {/* Sidebar header */}
          <div className={`p-4 flex ${isSidebarOpen ? 'justify-between' : 'justify-center'} items-center border-b border-gray-200 dark:border-gray-700`}>
            <div className={`flex items-center ${!isSidebarOpen && 'justify-center w-full'}`}>
              <MessageSquare className="text-primary-500" size={24} />
              {isSidebarOpen && <h1 className="ml-3 text-xl font-bold">ChatSync</h1>}
            </div>
          </div>
          
          {/* Sidebar content */}
          <div className="flex-1 overflow-y-auto py-4">
            <nav className="space-y-1 px-3">
              <NavLink
                to="/chat"
                className={({ isActive }) => 
                  `flex items-center px-4 py-3 rounded-lg ${
                    isActive ? 'bg-primary-50 dark:bg-primary-900/50 text-primary-600 dark:text-primary-400' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                  } ${!isSidebarOpen && 'justify-center'}`
                }
              >
                <MessageSquare className={isSidebarOpen ? 'mr-3' : ''} size={20} />
                {isSidebarOpen && <span>Messages</span>}
              </NavLink>
              
              <NavLink
                to="/settings"
                className={({ isActive }) => 
                  `flex items-center px-4 py-3 rounded-lg ${
                    isActive ? 'bg-primary-50 dark:bg-primary-900/50 text-primary-600 dark:text-primary-400' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                  } ${!isSidebarOpen && 'justify-center'}`
                }
              >
                <Settings className={isSidebarOpen ? 'mr-3' : ''} size={20} />
                {isSidebarOpen && <span>Settings</span>}
              </NavLink>
            </nav>
          </div>
          
          {/* Sidebar footer */}
          <div className="p-4 border-t border-gray-200 dark:border-gray-700">
            {isSidebarOpen ? (
              <>
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 rounded-full overflow-hidden mr-3">
                    <img 
                      src={user?.avatar || "https://i.pravatar.cc/150?img=68"} 
                      alt={user?.username || "User"} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{user?.username}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{user?.email}</p>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <button
                    onClick={toggleTheme}
                    className="flex-1 flex items-center justify-center p-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600"
                  >
                    {theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}
                  </button>
                  
                  <button
                    onClick={handleLogout}
                    className="flex-1 flex items-center justify-center p-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600"
                  >
                    <LogOut size={18} />
                  </button>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center space-y-4">
                <div className="w-10 h-10 rounded-full overflow-hidden">
                  <img 
                    src={user?.avatar || "https://i.pravatar.cc/150?img=68"} 
                    alt={user?.username || "User"} 
                    className="w-full h-full object-cover"
                  />
                </div>
                
                <button
                  onClick={toggleTheme}
                  className="p-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600"
                >
                  {theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}
                </button>
                
                <button
                  onClick={handleLogout}
                  className="p-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600"
                >
                  <LogOut size={18} />
                </button>
              </div>
            )}
          </div>
        </aside>
        
        {/* Main content area */}
        <main className="flex-1 overflow-hidden">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AppLayout;