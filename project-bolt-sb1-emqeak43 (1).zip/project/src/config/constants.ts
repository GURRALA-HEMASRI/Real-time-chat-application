// API Configuration
export const API_URL = 'http://localhost:8000/api';

// Socket Configuration
export const SOCKET_URL = 'http://localhost:8000';

// Message Types
export const MESSAGE_TYPES = {
  TEXT: 'text',
  IMAGE: 'image',
  FILE: 'file',
};

// User Status Types
export const USER_STATUS = {
  ONLINE: 'online',
  OFFLINE: 'offline',
  AWAY: 'away',
};

// Theme Options
export const THEMES = {
  LIGHT: 'light',
  DARK: 'dark',
};

// Animation Durations
export const ANIMATION = {
  FAST: 0.2,
  MEDIUM: 0.3,
  SLOW: 0.5,
};

// Placeholder Images
export const PLACEHOLDERS = {
  AVATAR: 'https://i.pravatar.cc/150',
};

// Storage Keys
export const STORAGE_KEYS = {
  TOKEN: 'token',
  THEME: 'theme',
};