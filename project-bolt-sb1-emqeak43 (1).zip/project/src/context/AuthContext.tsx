import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import axios from 'axios';
import { API_URL } from '../config/constants';

type User = {
  id: string;
  username: string;
  email: string;
  avatar?: string;
  status?: 'online' | 'offline' | 'away';
};

type AuthContextType = {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  loading: boolean;
  error: string | null;
};

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  // Check if the user is already logged in
  useEffect(() => {
    const token = localStorage.getItem('token');
    
    // For demo purposes, we'll create a mock user if token exists
    // In a real app, you would validate the token with your backend
    if (token) {
      setUser({
        id: '1',
        username: 'demouser',
        email: 'demo@example.com',
        avatar: 'https://i.pravatar.cc/150?img=68',
        status: 'online'
      });
    }
  }, []);
  
  const login = async (email: string, password: string) => {
    setLoading(true);
    setError(null);
    
    try {
      // In a real app, you'd make an API call here
      // const { data } = await axios.post(`${API_URL}/auth/login`, { email, password });
      
      // For demo purposes, we'll simulate a successful login
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Mock successful login
      const mockUser = {
        id: '1',
        username: 'demouser',
        email,
        avatar: 'https://i.pravatar.cc/150?img=68',
        status: 'online'
      };
      
      setUser(mockUser);
      localStorage.setItem('token', 'mock-jwt-token');
    } catch (err) {
      console.error('Login error:', err);
      setError('Invalid email or password');
    } finally {
      setLoading(false);
    }
  };
  
  const register = async (username: string, email: string, password: string) => {
    setLoading(true);
    setError(null);
    
    try {
      // In a real app, you'd make an API call here
      // const { data } = await axios.post(`${API_URL}/auth/register`, { username, email, password });
      
      // For demo purposes, we'll simulate a successful registration
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock successful registration
      const mockUser = {
        id: '1',
        username,
        email,
        avatar: 'https://i.pravatar.cc/150?img=68',
        status: 'online'
      };
      
      setUser(mockUser);
      localStorage.setItem('token', 'mock-jwt-token');
    } catch (err) {
      console.error('Registration error:', err);
      setError('Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };
  
  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      login,
      register,
      logout,
      loading,
      error
    }}>
      {children}
    </AuthContext.Provider>
  );
};